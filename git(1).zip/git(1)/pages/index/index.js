//index.js
//获取应用实例
const app = getApp()

Page({
  data: {

  },


  //测试代码开始
 
 //测试代码结束

  onLoad: function () {
    
  },

})
